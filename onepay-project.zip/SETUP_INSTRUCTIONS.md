# OnePay — Secure Backend Setup Instructions

Your app now has a secure backend! Your Flutterwave Secret Key and
Encryption Key are NEVER exposed to the browser — they live safely
on Vercel's servers only.

## Project structure

```
onepay-project/
├── api/
│   ├── initiate-payment.js   ← starts a payment (uses SECRET key)
│   └── verify-payment.js     ← confirms payment succeeded (uses SECRET key)
├── public/
│   └── index.html            ← your OnePay app (frontend)
├── vercel.json                ← tells Vercel how to run everything
└── package.json
```

## Step 1 — Upload this whole folder to GitHub

1. Go to your GitHub repo (onepay-app)
2. Delete the old single index.html file
3. Click "Add file" → "Upload files"
4. Drag in ALL files and folders from this project (keep folder structure!)
5. Commit changes

## Step 2 — Add your SECRET keys to Vercel (NOT GitHub!)

This is the most important step. Your secret keys must never sit in
GitHub or any public file — they go into Vercel's private Environment
Variables instead.

1. Go to vercel.com → your onepay-app project
2. Click "Settings"
3. Click "Environment Variables" on the left
4. Add these THREE variables one at a time:

   | Key                  | Value                                  |
   |-----------------------|-----------------------------------------|
   | FLW_SECRET_KEY        | (your Flutterwave Client Secret)        |
   | FLW_ENCRYPTION_KEY    | (your Flutterwave Encryption key)       |
   | FLW_PUBLIC_KEY        | (your Flutterwave Client ID / Public key)|

5. For each one, set environment to "Production, Preview, and Development"
6. Click "Save" after each

## Step 3 — Redeploy

1. Go to the "Deployments" tab
2. Click the three dots "..." on the latest deployment
3. Click "Redeploy"

This makes Vercel rebuild your app WITH the secret keys safely loaded
into the backend functions only.

## Step 4 — Test a payment

1. Open your live OnePay link
2. Sign up / log in
3. Try sending money or buying airtime
4. You'll be redirected to Flutterwave's secure payment page
5. After payment, you'll be redirected back to OnePay automatically
6. The transaction will appear in your history once verified

## Why this matters

Before: Your secret key would have been visible to anyone who viewed
your website's source code — a serious security risk for a banking app.

Now: Your secret key lives only on Vercel's private servers and is
never sent to anyone's browser. This is how real fintech apps work.

## Going live with Flutterwave

Remember — Flutterwave will require:
- CAC business registration
- BVN verification
- Business documentation review

Until that's approved, keep using TEST keys (from the "Test API keys"
tab on Flutterwave) so you can build and test safely without
real money moving.
