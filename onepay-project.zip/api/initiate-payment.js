// /api/initiate-payment.js
// This runs securely on Vercel's server — never exposed to the browser.
// It uses your Flutterwave SECRET KEY, which stays hidden from users.

export default async function handler(req, res) {
  // Only allow POST requests
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { amount, email, phone, name, description, txRef } = req.body;

    // Basic validation
    if (!amount || !email || !name) {
      return res.status(400).json({ error: 'Missing required fields: amount, email, name' });
    }

    // Call Flutterwave's secure server-to-server API using the SECRET key
    const flwResponse = await fetch('https://api.flutterwave.com/v3/payments', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.FLW_SECRET_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        tx_ref: txRef || `OP-${Date.now()}`,
        amount: amount,
        currency: 'NGN',
        redirect_url: `${req.headers.origin || 'https://onepay-app.vercel.app'}/payment-callback.html`,
        customer: {
          email: email,
          phonenumber: phone || '',
          name: name
        },
        customizations: {
          title: 'OnePay',
          description: description || 'OnePay transaction',
          logo: 'https://onepay-app.vercel.app/logo.png'
        }
      })
    });

    const data = await flwResponse.json();

    if (data.status === 'success') {
      return res.status(200).json({
        status: 'success',
        paymentLink: data.data.link
      });
    } else {
      return res.status(400).json({
        status: 'error',
        message: data.message || 'Payment initiation failed'
      });
    }
  } catch (error) {
    console.error('Payment initiation error:', error);
    return res.status(500).json({ status: 'error', message: 'Server error. Please try again.' });
  }
}
