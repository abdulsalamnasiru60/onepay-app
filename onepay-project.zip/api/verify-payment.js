// /api/verify-payment.js
// Confirms a payment actually succeeded before we mark it complete.
// Always verify server-side — never trust the browser alone for money matters.

export default async function handler(req, res) {
  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { transaction_id } = req.query;

    if (!transaction_id) {
      return res.status(400).json({ error: 'Missing transaction_id' });
    }

    const flwResponse = await fetch(
      `https://api.flutterwave.com/v3/transactions/${transaction_id}/verify`,
      {
        headers: {
          'Authorization': `Bearer ${process.env.FLW_SECRET_KEY}`,
        }
      }
    );

    const data = await flwResponse.json();

    if (data.status === 'success' && data.data.status === 'successful') {
      return res.status(200).json({
        status: 'success',
        amount: data.data.amount,
        currency: data.data.currency,
        txRef: data.data.tx_ref,
        customerEmail: data.data.customer.email,
        flwRef: data.data.flw_ref
      });
    } else {
      return res.status(200).json({ status: 'failed', message: 'Payment was not successful' });
    }
  } catch (error) {
    console.error('Verification error:', error);
    return res.status(500).json({ status: 'error', message: 'Could not verify payment' });
  }
}
